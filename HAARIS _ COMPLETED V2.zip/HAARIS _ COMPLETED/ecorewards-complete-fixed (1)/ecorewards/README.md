# 🌱 EcoRewards - Complete Application

Full-stack eco-rewards application with Spring Boot backend and Android frontend.

## Project Structure

```
ecorewards/
├── backend/              (Spring Boot REST API)
│   ├── src/main/java/com/ecorewards/
│   ├── src/main/resources/
│   └── pom.xml
├── frontend-android/     (Android WebView App)
│   ├── src/main/java/com/ecorewards/
│   ├── src/main/res/
│   ├── src/main/assets/
│   ├── build.gradle
│   └── AndroidManifest.xml
└── README.md
```

---

## 🚀 How to Run Backend

### Step 1: Open Backend in Android Studio
```
1. File → Open
2. Select: ecorewards/backend folder
3. Click "Open as Project"
4. Wait 5-10 minutes for Maven to download dependencies
```

### Step 2: Run the Backend

```
1. Find: backend/src/main/java/com/ecorewards/EcoRewardsApplication.java
2. Right-click on it
3. Select: "Run 'EcoRewardsApplication'"
4. Or press: Ctrl+Shift+F10
5. Wait 30-60 seconds
6. Look for: "Started EcoRewardsApplication"
```

### Step 3: Verify Backend is Running

```
Open browser:
http://localhost:8080/api/health

Should see:
{"status":"UP","service":"EcoRewards","version":"1.0.0"}
```

✅ Backend is now running on http://localhost:8080/api

---

## 🚀 How to Run Frontend

### Step 1: Open Frontend in New Android Studio Window

```
1. File → Open
2. Select: ecorewards/frontend-android folder
3. Click "Open"
4. Wait 3-5 minutes for Gradle to build
```

### Step 2: Start Android Emulator

```
1. Click: AVD Manager (Android Virtual Device)
2. Select a device (Pixel 4, API 30+)
3. Click: Play button to start
4. Wait 1-2 minutes for emulator to boot
```

### Step 3: Run the App

```
1. Find: frontend-android/src/main/java/com/ecorewards/MainActivity.java
2. Right-click on it
3. Select: "Run 'MainActivity'"
4. Wait 1-2 minutes for app to install and launch
5. App opens in emulator with Homepage loaded
```

---

## ✅ Testing the App

### Homepage (Challenges)
- ✓ Page loads with 3 random challenges
- ✓ Click "Accept" → Button changes to "Complete"
- ✓ Click "Complete" → Points added, button shows "✓ Done"
- ✓ Reload page → Different 3 challenges appear

### Profile
- ✓ Click profile icon (👤) → Opens profile page
- ✓ Shows username, email, joined year
- ✓ Click "Delete Account" → Confirmation modal
- ✓ Click "Confirm" → Account deleted, redirects to homepage

---

## 🔌 API Endpoints

All endpoints: http://localhost:8080/api

- GET /challenges
- POST /user_challenges
- POST /users/addPoints
- DELETE /users/{user_id}
- GET /health

---

## 💾 Database

Already configured:
- Host: sql.freedb.tech
- Database: freedb_EcoRewards
- User: freedb_BackendTeam

Location: backend/src/main/resources/application.properties

---

## 🎯 Quick Checklist

- [ ] Extract ZIP
- [ ] Open backend/ in Android Studio
- [ ] Run Backend (wait for "Started" message)
- [ ] Open frontend-android/ in new Android Studio
- [ ] Start Android emulator
- [ ] Run Frontend app
- [ ] Test: Load challenges, accept one, complete it
- [ ] Test: Go to profile, check delete button

---

**Happy Coding! 🌱**