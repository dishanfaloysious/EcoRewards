package com.ecorewards.service;

import com.ecorewards.model.Challenge;
import com.ecorewards.repository.ChallengeRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ChallengeService {
    private final ChallengeRepository challengeRepository;

    public ChallengeService(ChallengeRepository challengeRepository) { this.challengeRepository = challengeRepository; }

    public List<Challenge> getAllChallenges() { return challengeRepository.findAll(); }

    public Challenge getChallengeById(Integer id) { return challengeRepository.findById(id).orElse(null); }

    public Challenge createChallenge(Challenge challenge) { return challengeRepository.save(challenge); }

    public Challenge updateChallenge(Challenge challenge) { return challengeRepository.save(challenge); }

    public void deleteChallenge(Integer id) { challengeRepository.deleteById(id); }
}
