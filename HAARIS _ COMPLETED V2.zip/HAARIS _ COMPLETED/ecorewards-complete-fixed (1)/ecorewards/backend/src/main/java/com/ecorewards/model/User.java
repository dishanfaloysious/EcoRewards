package com.ecorewards.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.List;



@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer userId;

    @Column(nullable = false, unique = true)
    private String emailAddress;

    @Column(nullable = false)
    private String password;

    private Integer totalPoints;

    @Column(nullable = false, unique = true)
    private String username;

    // Only ignore the userChallenges to avoid recursion
    @OneToMany(mappedBy = "user")
    @JsonIgnore
    private List<UserChallenge> userChallenges;

    // Getters and setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getEmailAddress() { return emailAddress; }
    public void setEmailAddress(String emailAddress) { this.emailAddress = emailAddress; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public Integer getTotalPoints() { return totalPoints; }
    public void setTotalPoints(Integer totalPoints) { this.totalPoints = totalPoints; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public List<UserChallenge> getUserChallenges() { return userChallenges; }
    public void setUserChallenges(List<UserChallenge> userChallenges) { this.userChallenges = userChallenges; }
}
