package com.ecorewards.model;

import com.ecorewards.model.Challenge;
import com.ecorewards.model.User;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "user_challenges")
public class UserChallenge {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_challenge_id")
    private Integer userChallengeId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "challenge_id", nullable = false)
    private Challenge challenge;

    @Column(nullable = false)
    private String status;

    public UserChallenge() {}

    // Getters & Setters
    public Integer getUserChallengeId() { return userChallengeId; }
    public void setUserChallengeId(Integer userChallengeId) { this.userChallengeId = userChallengeId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Challenge getChallenge() { return challenge; }
    public void setChallenge(Challenge challenge) { this.challenge = challenge; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
