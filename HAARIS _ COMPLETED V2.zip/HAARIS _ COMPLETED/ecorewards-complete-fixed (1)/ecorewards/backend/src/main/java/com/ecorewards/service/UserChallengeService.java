package com.ecorewards.service;

import com.ecorewards.model.UserChallenge;
import com.ecorewards.repository.UserChallengeRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserChallengeService {
    private final UserChallengeRepository userChallengeRepository;

    public UserChallengeService(UserChallengeRepository userChallengeRepository) { this.userChallengeRepository = userChallengeRepository; }

    public List<UserChallenge> getAllUserChallenges() { return userChallengeRepository.findAll(); }

    public List<UserChallenge> getUserChallengesByUserId(Integer userId) { return userChallengeRepository.findByUserUserId(userId); }

    public UserChallenge createUserChallenge(UserChallenge userChallenge) { return userChallengeRepository.save(userChallenge); }

    public UserChallenge updateUserChallenge(UserChallenge userChallenge) { return userChallengeRepository.save(userChallenge); }

    public void deleteUserChallenge(Integer id) { userChallengeRepository.deleteById(id); }
}
