package com.ecorewards.controller;

import com.ecorewards.model.UserChallenge;
import com.ecorewards.service.UserChallengeService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/user-challenges")
public class UserChallengeController {
    private final UserChallengeService userChallengeService;

    public UserChallengeController(UserChallengeService userChallengeService) { this.userChallengeService = userChallengeService; }

    @GetMapping
    public List<UserChallenge> getAllUserChallenges() { return userChallengeService.getAllUserChallenges(); }

    @GetMapping("/user/{userId}")
    public List<UserChallenge> getUserChallengesByUser(@PathVariable Integer userId) {
        return userChallengeService.getUserChallengesByUserId(userId);
    }

    @PostMapping
    public UserChallenge createUserChallenge(@RequestBody UserChallenge userChallenge) {
        return userChallengeService.createUserChallenge(userChallenge);
    }

    @PutMapping("/{id}")
    public UserChallenge updateUserChallenge(@PathVariable Integer id, @RequestBody UserChallenge userChallenge) {
        userChallenge.setUserChallengeId(id);
        return userChallengeService.updateUserChallenge(userChallenge);
    }

    @DeleteMapping("/{id}")
    public void deleteUserChallenge(@PathVariable Integer id) {
        userChallengeService.deleteUserChallenge(id);
    }
}
