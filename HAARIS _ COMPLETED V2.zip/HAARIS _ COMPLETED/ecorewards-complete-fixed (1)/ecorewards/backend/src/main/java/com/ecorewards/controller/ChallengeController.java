package com.ecorewards.controller;

import com.ecorewards.model.Challenge;
import com.ecorewards.service.ChallengeService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/challenges")
public class ChallengeController {
    private final ChallengeService challengeService;

    public ChallengeController(ChallengeService challengeService) { this.challengeService = challengeService; }

    @GetMapping
    public List<Challenge> getAllChallenges() { return challengeService.getAllChallenges(); }

    @GetMapping("/{id}")
    public Challenge getChallenge(@PathVariable Integer id) { return challengeService.getChallengeById(id); }

    @PostMapping
    public Challenge createChallenge(@RequestBody Challenge challenge) { return challengeService.createChallenge(challenge); }

    @PutMapping("/{id}")
    public Challenge updateChallenge(@PathVariable Integer id, @RequestBody Challenge challenge) {
        challenge.setChallengeId(id);
        return challengeService.updateChallenge(challenge);
    }

    @DeleteMapping("/{id}")
    public void deleteChallenge(@PathVariable Integer id) { challengeService.deleteChallenge(id); }
}
