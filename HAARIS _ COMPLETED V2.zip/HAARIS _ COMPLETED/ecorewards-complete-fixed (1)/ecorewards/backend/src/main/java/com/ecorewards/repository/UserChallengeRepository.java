package com.ecorewards.repository;

import com.ecorewards.model.UserChallenge;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface UserChallengeRepository extends JpaRepository<UserChallenge, Integer> {
    List<UserChallenge> findByUserUserId(Integer userId);
}
