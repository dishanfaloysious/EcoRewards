// ============================================================
// CONFIGURATION - Change this line to switch environments
// ============================================================
const API_BASE = 'http://10.0.2.2:8080/api'; // Change to 'http://10.0.2.2:8080/api' for Android emulator

// ============================================================
// USER CONFIGURATION
// ============================================================
const userId = 1; // The logged-in user ID

// ============================================================
// DOM ELEMENTS
// ============================================================
const usernameEl = document.getElementById('profileUsername');
const emailEl = document.getElementById('profileEmail');
const joinedYearsEl = document.getElementById('joinedYears');

// ============================================================
// LOAD USER PROFILE
// ============================================================
async function loadUserProfile() {
    try {
        console.log('Fetching users from:', `${API_BASE}/users`);

        const res = await fetch(`${API_BASE}/users`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!res.ok) {
            const errorText = await res.text();
            throw new Error(`Failed to fetch users: ${res.status} ${res.statusText}. Response: ${errorText}`);
        }

        const users = await res.json();
        console.log('Users fetched:', users);

        // Find the current user by userId
        const user = users.find(u => u.userId === userId);

        if (!user) {
            throw new Error(`User with ID ${userId} not found`);
        }

        console.log('Current user:', user);

        // Update DOM with user data
        // Backend field names: userId, username, emailAddress, totalPoints
        usernameEl.textContent = user.username || 'Unknown';
        emailEl.textContent = user.emailAddress || 'No email';

        // Placeholder for joined years (backend doesn't provide joinedDate)
        // You can calculate this if you add a joinedDate field to your backend
        joinedYearsEl.textContent = '1'; // Placeholder value

    } catch (err) {
        console.error('Error loading profile:', err);

        // Display error state
        usernameEl.textContent = 'Error loading';
        emailEl.textContent = 'Error loading';
        joinedYearsEl.textContent = '0';

        // You could also show an alert or toast notification here
        alert('Failed to load profile. Please check your connection and try again.');
    }
}

// ============================================================
// DELETE ACCOUNT MODAL HANDLERS
// ============================================================
const deleteBtn = document.getElementById('deleteBtn');
const deleteModal = document.getElementById('deleteModal');
const cancelDelete = document.getElementById('cancelDelete');
const confirmDelete = document.getElementById('confirmDelete');

// Show delete confirmation modal
deleteBtn.addEventListener('click', () => {
    deleteModal.style.display = 'flex';
});

// Hide modal on cancel
cancelDelete.addEventListener('click', () => {
    deleteModal.style.display = 'none';
});

// Handle account deletion
confirmDelete.addEventListener('click', async () => {
    try {
        console.log('Deleting user:', userId);

        const res = await fetch(`${API_BASE}/users/${userId}`, {
            method: 'DELETE'
        });

        if (!res.ok) {
            throw new Error(`Failed to delete user: ${res.status} ${res.statusText}`);
        }

        console.log('User deleted successfully');
        alert('Account deleted successfully');

        // Redirect to login or home page
        window.location.href = 'index.html'; // Change to your login page

    } catch (err) {
        console.error('Error deleting account:', err);
        alert('Failed to delete account. Please try again.');
    } finally {
        deleteModal.style.display = 'none';
    }
});

// Close modal if clicking outside of it
deleteModal.addEventListener('click', (e) => {
    if (e.target === deleteModal) {
        deleteModal.style.display = 'none';
    }
});

// ============================================================
// INITIALIZE ON PAGE LOAD
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('Profile page loaded');
    console.log('API Base URL:', API_BASE);
    console.log('User ID:', userId);

    loadUserProfile();
});