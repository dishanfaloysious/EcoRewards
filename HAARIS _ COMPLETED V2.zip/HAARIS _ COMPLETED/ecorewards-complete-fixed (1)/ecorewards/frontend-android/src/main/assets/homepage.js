// ============================================================
// CONFIGURATION - Change this line to switch environments
// ============================================================
const API_BASE = 'http://10.0.2.2:8080/api'; // Change to 'http://10.0.2.2:8080/api' for Android emulator

// ============================================================
// USER CONFIGURATION
// ============================================================
const userId = 1; // The logged-in user ID (must exist in database)

// ============================================================
// GLOBAL STATE
// ============================================================
let currentUserPoints = 0;

// ============================================================
// DOM ELEMENTS
// ============================================================
const challengeList = document.getElementById('challengeList');
const headerPoints = document.getElementById('headerPoints');

// ============================================================
// INITIALIZE ON PAGE LOAD
// ============================================================
document.addEventListener('DOMContentLoaded', async () => {
    console.log('Homepage loaded');
    console.log('API Base URL:', API_BASE);
    console.log('User ID:', userId);

    // Fetch user points first
    await fetchUserPoints();

    // Load and render all challenges
    await loadAndRenderChallenges();

    // Update header with current points
    updateHeaderPoints();
});

// ============================================================
// FETCH USER POINTS
// ============================================================
async function fetchUserPoints() {
    try {
        console.log('Fetching user points from:', `${API_BASE}/users`);

        const res = await fetch(`${API_BASE}/users`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!res.ok) {
            const errorText = await res.text();
            throw new Error(`Failed to fetch users: ${res.status} ${res.statusText}. Response: ${errorText}`);
        }

        const users = await res.json();
        console.log('Users fetched:', users);

        // Find the current user by userId
        const user = users.find(u => u.userId === userId);

        if (!user) {
            throw new Error(`User with ID ${userId} not found`);
        }

        // Get user's total points
        currentUserPoints = user.totalPoints || 0;
        console.log('User points:', currentUserPoints);

    } catch (err) {
        console.error('Error fetching user points:', err);
        currentUserPoints = 0;
    }
}

// ============================================================
// LOAD AND RENDER ALL CHALLENGES
// ============================================================
async function loadAndRenderChallenges() {
    try {
        console.log('Loading challenges...');

        // Fetch all challenges
        const resChallenges = await fetch(`${API_BASE}/challenges`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });

        if (!resChallenges.ok) {
            const errorText = await resChallenges.text();
            throw new Error(`Failed to fetch challenges: ${resChallenges.status}. Response: ${errorText}`);
        }
        const challenges = await resChallenges.json();
        console.log('Challenges fetched:', challenges);

        // Fetch user challenges (challenges the user has accepted/completed)
        const resUserChallenges = await fetch(`${API_BASE}/user-challenges/user/${userId}`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });
        let userChallenges = [];

        if (resUserChallenges.ok) {
            userChallenges = await resUserChallenges.json();
            console.log('User challenges fetched:', userChallenges);
        } else {
            console.log('No user challenges found or error fetching (status:', resUserChallenges.status, ')');
        }

        // Clear the challenge list
        challengeList.innerHTML = '';

        // Render each challenge
        challenges.forEach(challenge => {
            const challengeId = challenge.challengeId;

            // Check if user has this challenge
            const userChallenge = userChallenges.find(
                uc => uc.challenge && uc.challenge.challengeId === challengeId
            );

            // Determine the status: 'new', 'pending', or 'completed'
            const status = userChallenge ? userChallenge.status : 'new';

            console.log(`Challenge ${challengeId} (${challenge.title}): status = ${status}`);

            // Create challenge list item
            const li = document.createElement('li');
            li.className = 'challenge';
            li.innerHTML = `
                <div class="challenge-title">${challenge.title}</div>
                <div class="challenge-sub">${challenge.description}</div>
                <button></button>
            `;

            const btn = li.querySelector('button');

            // Set button state based on challenge status
            if (status === 'completed') {
                // Challenge is completed
                btn.textContent = '✓ Done';
                btn.disabled = true;
            } else if (status === 'pending') {
                // Challenge is accepted but not completed
                btn.textContent = 'Complete';
                btn.onclick = () => completeChallenge(
                    btn,
                    userChallenge.userChallengeId,
                    challenge.points,
                    challenge.title
                );
            } else {
                // Challenge is new (not accepted yet)
                btn.textContent = 'Accept';
                btn.onclick = () => acceptChallenge(
                    btn,
                    challengeId,
                    challenge.points,
                    challenge.title
                );
            }

            challengeList.appendChild(li);
        });

        console.log('Challenges rendered successfully');

    } catch (err) {
        console.error('Error loading challenges:', err);
        challengeList.innerHTML = '<li style="color:red; padding: 20px;">Failed to load challenges. Error: ' + err.message + '</li>';
    }
}

// ============================================================
// ACCEPT CHALLENGE
// ============================================================
async function acceptChallenge(btn, challengeId, pointsValue, challengeTitle) {
    console.log(`Accepting challenge: ${challengeTitle} (ID: ${challengeId})`);

    // Disable button to prevent double-clicks
    btn.disabled = true;
    btn.textContent = 'Accepting...';

    try {
        const res = await fetch(`${API_BASE}/user-challenges`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user: { userId: userId },
                challenge: { challengeId: challengeId },
                status: 'pending'
            })
        });

        if (!res.ok) {
            throw new Error(`Failed to accept challenge: ${res.status} ${res.statusText}`);
        }

        const userChallenge = await res.json();
        console.log('Challenge accepted:', userChallenge);

        // Update button to "Complete" state
        btn.textContent = 'Complete';
        btn.disabled = false;

        // Update onclick handler to complete the challenge
        btn.onclick = () => completeChallenge(
            btn,
            userChallenge.userChallengeId,
            pointsValue,
            challengeTitle
        );

    } catch (err) {
        console.error('Error accepting challenge:', err);

        // Reset button on error
        btn.textContent = 'Accept';
        btn.disabled = false;

        alert(`Failed to accept challenge "${challengeTitle}". Please try again.`);
    }
}

// ============================================================
// COMPLETE CHALLENGE
// ============================================================
async function completeChallenge(btn, userChallengeId, pointsValue, challengeTitle) {
    console.log(`Completing challenge: ${challengeTitle} (UserChallenge ID: ${userChallengeId})`);

    // Disable button to prevent double-clicks
    btn.disabled = true;
    btn.textContent = 'Completing...';

    try {
        const res = await fetch(`${API_BASE}/user-challenges/${userChallengeId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: 'completed'
            })
        });

        if (!res.ok) {
            throw new Error(`Failed to complete challenge: ${res.status} ${res.statusText}`);
        }

        console.log('Challenge completed successfully');

        // Update button to "Done" state
        btn.textContent = '✓ Done';

        // Add points to current user's total
        currentUserPoints += pointsValue;
        console.log(`Points added: +${pointsValue}. New total: ${currentUserPoints}`);

        // Update the header display
        updateHeaderPoints();

        // Show a success message
        alert(`Challenge completed! You earned ${pointsValue} points!`);

    } catch (err) {
        console.error('Error completing challenge:', err);

        // Reset button on error
        btn.textContent = 'Complete';
        btn.disabled = false;

        alert(`Failed to complete challenge "${challengeTitle}". Please try again.`);
    }
}

// ============================================================
// UPDATE HEADER POINTS DISPLAY
// ============================================================
function updateHeaderPoints() {
    if (headerPoints) {
        headerPoints.textContent = `Points: ${currentUserPoints}`;
        console.log('Header updated with points:', currentUserPoints);
    } else {
        console.warn('headerPoints element not found in DOM');
    }
}